﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project01_9535_6781_dotNet5780
{
    public class Class1
    {
    }
}
