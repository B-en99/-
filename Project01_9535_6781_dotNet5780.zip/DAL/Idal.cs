﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    interface Idal
    {
        void AddCustomer(); // הוספת דרישת לקוח
        void CustomerRequirementUpdate(); // עדכון דרישת לקוח 

        void AddHostingUnit(); // הוספת יחידת אירוח 
        void DeleteHostingUnit(); // מחיקת יחידת אירוח 
        void HostingUnitUpdate(); // עדכון יחידת אירוח 

        void AddInvitation(); // הוספת הזמנה 
        void UpdateInvitation(); // עדכון הזמנה 
        void GetListOfAllAccommodationUnits(); // קבלת רשימת כל יחידות האירוח 
        void ListAllCustomerRequirements(); // קבלת רשימת כל דרישות הלקוחות 
        void ReceiveListOfAllInvitations(); // קבלת רשימת כל ההזמנות
        void ReceiveListOfAllExistingBankBranchesInIsrael(); // קבלת רשימת כל סניפי הבנק הקיימים בארץ 
    }
}
