﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    class HostingUnit
    {
        static int HostingUnitKey = 10000000;
        Host Owner;
        string HostingUnitName { get; set; }
        // Creates an initialized boolean matrix in FALSE:
        bool[,] Diary = new bool[12, 31];
    }
}
