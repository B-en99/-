﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    class BankBranch
    {
        int BankNumber { get; set; }
        string BankName { get; set; }
        int BranchNumber { get; set; }
        string BranchAddress { get; set; }
        string BranchCity { get; set; }
    }
}
